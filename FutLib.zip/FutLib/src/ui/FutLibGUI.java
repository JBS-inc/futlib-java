/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import ctrl.LibraryHandler;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.table.DefaultTableModel;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTable;
import model.Achievement;

/**
 *
 * @author Stephan
 */
public class FutLibGUI extends javax.swing.JFrame {

    /**
     * Handler
     */
    LibraryHandler handler;

    /**
     * makes sure only one dialog window displaying a QR code is open at a time
     */
    boolean QRDISPLAYED;

    /**
     * Dialog box displaying QR image
     */
    /**
     * Creates new form FutLibGUI
     */
    public FutLibGUI() {
        initComponents();
        /* set frame icon */
        ImageIcon img = new ImageIcon("res/icon.png");
        this.setIconImage(img.getImage());
        
        /* set table sortable */
        jTable1.setAutoCreateRowSorter(true);

        //dialog.pack();
        Action requestQR = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* only open a new one when this window is open */
                if (QRDISPLAYED) {
                    return;
                }

                /* get selected */
                JTable table = (JTable) e.getSource();
                int modelRow = Integer.valueOf(e.getActionCommand());
                String chosenuiid = (String) table.getModel().getValueAt(modelRow, 6);

                /**
                 * download QR image
                 */
                handler.requestQRcode(chosenuiid);
                System.out.println("QR code requested");

                JDialog dialog;
                dialog = new JDialog();
                dialog.setUndecorated(false);
                dialog.setAlwaysOnTop(true);
                dialog.setLocation(new Point(150, 150));
                dialog.setSize(599, 599);
                dialog.addWindowListener(new WindowAdapter() {

                    public void windowClosing(WindowEvent e) {
                        QRDISPLAYED = false;
                    }
                });
                JLabel label = new JLabel(new ImageIcon("res/imageQR" + chosenuiid + ".png"));

                dialog.add(label);
                dialog.pack();
                dialog.repaint();
                dialog.setVisible(true);

                QRDISPLAYED = true;
            }
        };
        ButtonColumn buttonColumn_RequestQR = new ButtonColumn(jTable1, requestQR, 7);

        Action resetQR = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* get selected */
                JTable table = (JTable) e.getSource();
                int modelRow = Integer.valueOf(e.getActionCommand());
                String chosenuiid = (String) table.getModel().getValueAt(modelRow, 6);

                handler.resetQRcode(chosenuiid);
                handler.loadAchievements();
                displayAchievementes();
            }
        };
        ButtonColumn buttonColumn_ResetQR = new ButtonColumn(jTable1, resetQR, 8);

        Action deleteRow = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* get selected */
                JTable table = (JTable) e.getSource();
                int modelRow = Integer.valueOf(e.getActionCommand());
                String chosenuiid = (String) table.getModel().getValueAt(modelRow, 6);

                //TODO
            }
        };
        ButtonColumn buttonColumn_Delete = new ButtonColumn(jTable1, resetQR, 9);

        handler = new LibraryHandler("http://138.68.146.164:3000");
        //handler = new LibraryHandler("http://192.168.5.111:3000");
        //handler.loadLibrary("", "");
        //handler.loadAchievements();
        
        //UserHandler usrhdl = new UserHandler("http://138.68.146.164:3000");
        //UserHandler usrhdl = new UserHandler("http://192.168.5.111:3000");
        //usrhdl.loadUser("", "");
        
        //System.out.println("" + usrhdl.loadPoints());
        //System.out.println("" + usrhdl.getPoints());
        //usrhdl.loadAchievements();
        
       // System.out.println("" + usrhdl.getAchievements().size());
        //System.out.println("" + usrhdl.handleQRscan("9fedb5e5-0979-46f7-afad-acf97da84bcb"));
        
        //usrhdl.handleQRscan("");
        
        /* initially disable buttons */
        buttonSaveChanges.setEnabled(false);
        buttonAdd.setEnabled(false);

        // UserHandler usrhdl = new UserHandler("http://192.168.5.227:3000");
        // usrhdl.loadUser("test", "test");
        // usrhdl.loadAchievements();
        // System.out.println("" + usrhdl.getAchievements().size());
    }

    protected long timeToLong(String timeasstring) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");
            Date date = sdf.parse(timeasstring);

            return date.getTime();
        } catch (Exception e) {

        }
        return 0;
    }

    protected String timeToString(long timeaslong) {
        Date date = new Date(timeaslong);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");
        String formattedDate = sdf.format(date);

        return formattedDate;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        buttonSaveChanges = new javax.swing.JButton();
        buttonSignIn = new javax.swing.JButton();
        tfEnterName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        buttonAdd = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tfAddName = new javax.swing.JTextField();
        tfAddExpires = new javax.swing.JTextField();
        cbAddSecret = new javax.swing.JCheckBox();
        tfAddPoints = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        taAddDescription = new javax.swing.JTextArea();
        tfPPH = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        labelError = new javax.swing.JLabel();
        tfEnterPw = new javax.swing.JPasswordField();
        labelName = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Library Achievement Manager");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Name", "Description", "Created", "Expires", "Secret", "Points rewarded", "Uuid", "QR", "QR", "Delete"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Boolean.class, java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable1);

        buttonSaveChanges.setText("Save Changes");
        buttonSaveChanges.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonSaveChangesActionPerformed(evt);
            }
        });

        buttonSignIn.setText("Sign In");
        buttonSignIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonSignInActionPerformed(evt);
            }
        });

        jLabel1.setText("Name:");

        jLabel2.setText("Password:");

        buttonAdd.setText("Add");
        buttonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAddActionPerformed(evt);
            }
        });

        jLabel3.setText("Add Achievement");

        jLabel4.setText("Name");

        jLabel5.setText("Description");

        jLabel7.setText("Expires on");

        jLabel8.setText("Is secret");

        jLabel9.setText("Points");

        taAddDescription.setColumns(20);
        taAddDescription.setRows(5);
        jScrollPane1.setViewportView(taAddDescription);

        tfPPH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPPHActionPerformed(evt);
            }
        });

        jLabel6.setText("Points:");

        jLabel10.setText("/Hour");

        labelName.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 36)); // NOI18N
        labelName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labelError, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonSaveChanges))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(tfAddName, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 342, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(75, 75, 75)
                                        .addComponent(jLabel8))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(tfAddExpires, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbAddSecret)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(tfAddPoints, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(buttonAdd)))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tfPPH, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 724, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tfEnterName, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfEnterPw, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(labelName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(34, 34, 34)))
                        .addComponent(buttonSignIn)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(buttonSignIn)
                        .addComponent(tfEnterName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)
                        .addComponent(tfEnterPw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(labelName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfPPH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel10))
                .addGap(48, 48, 48)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbAddSecret)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(buttonAdd)
                        .addComponent(tfAddPoints, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(tfAddExpires, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfAddName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(buttonSaveChanges)
                    .addComponent(labelError, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonSaveChangesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonSaveChangesActionPerformed

        /* send any potentially created achievements */
        handler.sendCreatedAchievements();
        handler.loadAchievements();
        displayAchievementes();
        buttonSaveChanges.setEnabled(false);

        /* send library data, TODO which for now is just points/hour */
        handler.sendData();

    }//GEN-LAST:event_buttonSaveChangesActionPerformed

    private void buttonSignInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonSignInActionPerformed

        String in_name = tfEnterName.getText();
        String in_pw = tfEnterPw.getText();

        /* login and load library */
        handler.loadLibrary(in_name, in_pw);

        if (!handler.isReady()) {
            return;
        }

        /**
         * load library data
         */
        handler.loadAchievements();
        handler.loadData();

        /* show points/hour, name of library */
        tfPPH.setText("" + handler.getPointsPerHour());
        labelName.setText(handler.getName());

        /* display all achievements */
        displayAchievementes();

        /* enable buttons */
        buttonAdd.setEnabled(true);
        /* change button to sign out button, TODO for now just disable it */
        buttonSignIn.setEnabled(false);
        tfEnterName.setEnabled(false);
        tfEnterPw.setEnabled(false);

    }//GEN-LAST:event_buttonSignInActionPerformed

    private void buttonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAddActionPerformed

        if (!handler.isReady()) {
            return;
        }

        /* add new achievement */
        String name = tfAddName.getText();
        String desc = taAddDescription.getText();

        boolean isSecret = cbAddSecret.isSelected();
        int points = 0;
        if (tfAddPoints.getText().length() > 0 && tfAddPoints.getText().matches("\\d+")) {
            points = Integer.parseInt(tfAddPoints.getText());
        }
        /* add to list */
        if (handler.createAchievement(name, desc, isSecret, points)) {
            displayAchievementes();
            /* enable save changes button */
            buttonSaveChanges.setEnabled(true);
        }

    }//GEN-LAST:event_buttonAddActionPerformed

    private void tfPPHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPPHActionPerformed

        buttonSaveChanges.setEnabled(true);
    }//GEN-LAST:event_tfPPHActionPerformed

    private void displayAchievementes() {

        if (!handler.isReady()) {
            return;
        }

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        /* clear table */
        model.setRowCount(0);

        /* add rows */
        for (Achievement ach : handler.getAchievements()) {
            Vector data = new Vector();
            data.add(ach.getName());
            data.add(ach.getDesc());
            data.add(timeToString(ach.getCreated()));
            if (ach.getExpires() < 50000) {
                data.add("-");
            } else {
                data.add(timeToString(ach.getExpires()));
            }
            data.add(ach.isSecret());
            data.add(ach.getPoints());
            data.add(ach.getUuid());
            data.add("Show QR");
            data.add("RESET QR");
            data.add("X");
            model.addRow(data);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FutLibGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FutLibGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FutLibGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FutLibGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FutLibGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonAdd;
    private javax.swing.JButton buttonSaveChanges;
    private javax.swing.JButton buttonSignIn;
    private javax.swing.JCheckBox cbAddSecret;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelError;
    private javax.swing.JLabel labelName;
    private javax.swing.JTextArea taAddDescription;
    private javax.swing.JTextField tfAddExpires;
    private javax.swing.JTextField tfAddName;
    private javax.swing.JTextField tfAddPoints;
    private javax.swing.JTextField tfEnterName;
    private javax.swing.JPasswordField tfEnterPw;
    private javax.swing.JTextField tfPPH;
    // End of variables declaration//GEN-END:variables
}
